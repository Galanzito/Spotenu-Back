"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserType = exports.userTypeToString = exports.stringToUserType = exports.User = void 0;
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
class User {
    constructor(id, name, email, nickname, password, type, description) { }
}
exports.User = User;
exports.stringToUserType = (type) => {
    switch (type) {
        case 'NORMAL':
            return UserType.NORMAL;
        case 'PREMIUM':
            return UserType.PREMIUM;
        case 'BAND':
            return UserType.BAND;
        default:
            throw new InvalidParameterError_1.InvalidParameterError("Invalid User Type");
    }
};
exports.userTypeToString = (type) => {
    switch (type) {
        case UserType.NORMAL:
            return 'NORMAL';
        case UserType.PREMIUM:
            return 'PREMIUM';
        case UserType.BAND:
            return 'BAND';
        default:
            throw new InvalidParameterError_1.InvalidParameterError("Invalid User Type");
    }
};
var UserType;
(function (UserType) {
    UserType["NORMAL"] = "NORMAL";
    UserType["PREMIUM"] = "PREMIUM";
    UserType["BAND"] = "BAND";
})(UserType = exports.UserType || (exports.UserType = {}));
;
