"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserBand = void 0;
class UserBand {
    constructor(name, email, nickname, isAproved) { }
}
exports.UserBand = UserBand;
